var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_Desa_Paluta_TitikKoordinat_1 = new ol.format.GeoJSON();
var features_Desa_Paluta_TitikKoordinat_1 = format_Desa_Paluta_TitikKoordinat_1.readFeatures(json_Desa_Paluta_TitikKoordinat_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Desa_Paluta_TitikKoordinat_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Desa_Paluta_TitikKoordinat_1.addFeatures(features_Desa_Paluta_TitikKoordinat_1);
var lyr_Desa_Paluta_TitikKoordinat_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Desa_Paluta_TitikKoordinat_1, 
                style: style_Desa_Paluta_TitikKoordinat_1,
                popuplayertitle: 'Desa_Paluta_TitikKoordinat',
                interactive: true,
    title: 'Desa_Paluta_TitikKoordinat<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_0.png" /> AEK BARGOT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_1.png" /> AEK BAYUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_2.png" /> AEK GAMBIR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_3.png" /> AEK GODANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_4.png" /> AEK HARUAYA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_5.png" /> AEK ILUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_6.png" /> AEK JABUT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_7.png" /> AEK JANGKANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_8.png" /> AEK KANAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_9.png" /> AEK KUNDUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_10.png" /> AEK NAULI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_11.png" /> AEK RAOTAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_12.png" /> AEK SIALA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_13.png" /> AEK SIMANAP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_14.png" /> AEK SUHAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_15.png" /> AEK SUHAT JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_16.png" /> AEK SUHAT TR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_17.png" /> AEK SUNDUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_18.png" /> AEK TANGGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_19.png" /> AEK TOLONG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_20.png" /> AEK TOROP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_21.png" /> AEKRARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_22.png" /> ALOBAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_23.png" /> AMBASANG NATIGOR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_24.png" /> ARSE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_25.png" /> BAHAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_26.png" /> BAHAP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_27.png" /> BALAKA TOROP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_28.png" /> BALAKKA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_29.png" /> BALIMBING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_30.png" /> BALIMBING JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_31.png" /> BALIMBING JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_32.png" /> BANDAR NAULI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_33.png" /> BANGKUDU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_34.png" /> BANGUN PURBA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_35.png" /> BARA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_36.png" /> BARGOT TOPONG JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_37.png" /> BARGOT TOPONG JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_38.png" /> BARINGIN SIL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_39.png" /> BARINGIN SIP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_40.png" /> BATANG BARUHAR  JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_41.png" /> BATANG BARUHAR JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_42.png" /> BATANG ONANG BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_43.png" /> BATANG ONANG LAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_44.png" /> BATANG PANE I<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_45.png" /> BATANG PANE II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_46.png" /> BATANG PANE III<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_47.png" /> BATU GANA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_48.png" /> BATU HIBUL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_49.png" /> BATU MAMAK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_50.png" /> BATU NANGGAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_51.png" /> BATU PULUT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_52.png" /> BATU RANCANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_53.png" /> BATU RUNDING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_54.png" /> BATU SUNDUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_55.png" /> BATU TAMBUN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_56.png" /> BATU TUNGGAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_57.png" /> BINANGA GUMBOT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_58.png" /> BINANGA PANASAHAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_59.png" /> BINTAIS JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_60.png" /> BOLATAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_61.png" /> BONAN DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_62.png" /> BOTUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_63.png" /> BUKIT RAYA  SORDANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_64.png" /> BUKIT TINGGI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_65.png" /> BUNUT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_66.png" /> DALIHAN NATOLU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_67.png" /> DOLOK SAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_68.png" /> DOLOK SANGGUL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_69.png" /> GADUNG HOLBUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_70.png" /> GALANGGANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_71.png" /> GARIANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_72.png" /> GAROGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_73.png" /> GARONGGANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_74.png" /> GONTING BANGE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_75.png" /> GULANGAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_76.png" /> GUMARUNTAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_77.png" /> GUMARUPU BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_78.png" /> GUMARUPU LAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_79.png" /> GUMBOT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_80.png" /> GUNUNG BARINGIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_81.png" /> GUNUNG INTAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_82.png" /> GUNUNG MANAON I<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_83.png" /> GUNUNG MANAON II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_84.png" /> GUNUNG MANAON III<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_85.png" /> GUNUNG MANAON SIM<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_86.png" /> GUNUNG MANAON UB<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_87.png" /> GUNUNG MARIA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_88.png" /> GUNUNG MARTUA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_89.png" /> GUNUNG SELAMAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_90.png" /> GUNUNG SORMIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_91.png" /> GUNUNG TUA BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_92.png" /> GUNUNG TUA JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_93.png" /> GUNUNG TUA JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_94.png" /> GUNUNG TUA TONGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_95.png" /> GUNUNGTUA BATANG ONANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_96.png" /> GUNUNGTUA TUMBU JATI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_97.png" /> HADUNGDUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_98.png" /> HAJORAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_99.png" /> HALONGONAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_100.png" /> HAMBIRI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_101.png" /> HAMBULO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_102.png" /> HASAHATAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_103.png" /> HASAMBI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_104.png" /> HATIRAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_105.png" /> HITEURAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_106.png" /> HOTANG SASA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_107.png" /> HULA BARINGIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_108.png" /> HUTA BARINGIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_109.png" /> HUTA BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_110.png" /> HUTA BARU SIL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_111.png" /> HUTA BARU SIP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_112.png" /> HUTA LAMBUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_113.png" /> HUTA PASIR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_114.png" /> HUTA RAJA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_115.png" /> HUTABARU NANGKA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_116.png" /> HUTAIMBARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_117.png" /> HUTAIMBARU GUL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_118.png" /> HUTAIMBARU II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_119.png" /> HUTAIMBARU SIMUNDOL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_120.png" /> HUTALOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_121.png" /> HUTANOPAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_122.png" /> JABI JABI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_123.png" /> JAMBU TONANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_124.png" /> JAMBUR BATU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_125.png" /> JANJI MANAHAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_126.png" /> JANJI MANAHAN GNT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_127.png" /> JANJI MANAHAN GUL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_128.png" /> JANJI MANAHAN SIL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_129.png" /> JANJI MATOGU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_130.png" /> JANJI MAULI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_131.png" /> JAPINULIK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_132.png" /> KARANG ANYAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_133.png" /> KOSIK PUTIH<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_134.png" /> KUALA SIMPANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_135.png" /> LABUHAN JURUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_136.png" /> LANGKIMAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_137.png" /> LANTOSAN I<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_138.png" /> LANTOSAN II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_139.png" /> LIANG  HASONA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_140.png" /> LOSUNG BATU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_141.png" /> LUBUK GODANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_142.png" /> LUBUK KUNDUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_143.png" /> LUBUK LANJANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_144.png" /> LUBUK TORAP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_145.png" /> MALINO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_146.png" /> MANANTI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_147.png" /> MANARE TUA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_148.png" /> MANDASIP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_149.png" /> MANGALEDANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_150.png" /> MANGALEDANG LAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_151.png" /> MARLAUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_152.png" /> MARTUJUAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_153.png" /> MOMPANG DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_154.png" /> MOMPANG I<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_155.png" /> MOMPANG II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_156.png" /> MOMPANG LOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_157.png" /> MORANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_158.png" /> MUARA SIGAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_159.png" /> NABONGAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_160.png" /> NABONGGAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_161.png" /> NABUNDONG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_162.png" /> NAGA SARIBU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_163.png" /> NAHULA JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_164.png" /> NAHULA JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_165.png" /> NAPA HALAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_166.png" /> NAPA LANCAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_167.png" /> NAPA LOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_168.png" /> NAPAGADUNG LAUT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_169.png" /> NAPASUNDALI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_170.png" /> PADANG BARUAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_171.png" /> PADANG BUJUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_172.png" /> PADANG BUJUR BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_173.png" /> PADANG GARUGUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_174.png" /> PADANG MALAKKA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_175.png" /> PADANG MANJOIR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_176.png" /> PADANG MATINGGI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_177.png" /> PADANG MATINGGI GNT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_178.png" /> PADANG MATINGGI SIMUNDOL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_179.png" /> PAGAR GUNUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_180.png" /> PAGARAN BATU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_181.png" /> PAGARAN JULU II<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_182.png" /> PAGARAN SINGKAM<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_183.png" /> PAGARAN SIREGAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_184.png" /> PAGARAN TONGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_185.png" /> PAMARAI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_186.png" /> PAMONORAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_187.png" /> PAMUNTARAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_188.png" /> PANCA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_189.png" /> PANCUR PANGKO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_190.png" /> PANGARAMBANGAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_191.png" /> PANGARAN JULU I<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_192.png" /> PANGIRKIRAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_193.png" /> PANGKAL DOLOK JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_194.png" /> PANGKAL DOLOK LAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_195.png" /> PANYABUNGAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_196.png" /> PAOLAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_197.png" /> PARAN GADUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_198.png" /> PARAN HONAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_199.png" /> PARAN NANGKA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_200.png" /> PARAN PADANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_201.png" /> PARAN TONGA SIM<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_202.png" /> PARANG PADANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_203.png" /> PARAU SORAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_204.png" /> PARIGI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_205.png" /> PARLIMBATAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_206.png" /> PARMERAAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_207.png" /> PARSARMAAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_208.png" /> PARUPUK JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_209.png" /> PARUPUK JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_210.png" /> PASANG LELA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_211.png" /> PASAR GUNUNG TUA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_212.png" /> PASAR MATANGGOR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_213.png" /> PASAR SAYUR MATINGGI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_214.png" /> PASAR SIMUNDOL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_215.png" /> PASAR SIPIONGOT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_216.png" /> PASIR AMPOLU HOPONG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_217.png" /> PASIR BARA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_218.png" /> PASIR LANCAT UB<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_219.png" /> PASIR PINANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_220.png" /> PAYA BAHUNG UB<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_221.png" /> PAYA OMBIK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_222.png" /> PIJOR KOLING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_223.png" /> PINARIK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_224.png" /> PINTU BOSI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_225.png" /> PINTU PADANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_226.png" /> PINTU PADANG MERDEKA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_227.png" /> PORTIBI JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_228.png" /> PORTIBI JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_229.png" /> PULO LIMAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_230.png" /> PURBA SINOMBA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_231.png" /> PURBA TUA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_232.png" /> PURBA TUA DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_233.png" /> RAHUNING JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_234.png" /> RAMPA JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_235.png" /> RAMPA JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_236.png" /> RANCARAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_237.png" /> RONDAMAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_238.png" /> RONDAMAN DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_239.png" /> RONDAMAN LOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_240.png" /> RONDAMAN SIBUREGAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_241.png" /> RONGKARE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_242.png" /> SABA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_243.png" /> SABA BANGUN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_244.png" /> SABA BANGUNAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_245.png" /> SABA SITAHUL TAHUL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_246.png" /> SALUSUHAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_247.png" /> SAMPURAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_248.png" /> SAMPURAN SIMARLOTING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_249.png" /> SANDEAN JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_250.png" /> SANDEAN JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_251.png" /> SANDEAN TONGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_252.png" /> SAYUR MATINGGI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_253.png" /> SAYUR MATINGGI JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_254.png" /> SIALA GUNDI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_255.png" /> SIALANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_256.png" /> SIALANG DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_257.png" /> SIANCIMUN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_258.png" /> SIBAGASI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_259.png" /> SIBATANG KAYU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_260.png" /> SIBAYO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_261.png" /> SIBAYO JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_262.png" /> SIBIO BIO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_263.png" /> SIBORU ANGIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_264.png" /> SIBURBUR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_265.png" /> SIDINGKAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_266.png" /> SIDONG-DONG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_267.png" /> SIGAGAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_268.png" /> SIGALA GALA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_269.png" /> SIGAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_270.png" /> SIGAMA NAPAHALAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_271.png" /> SIGAMA UJUNG GADING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_272.png" /> SIGIMBAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_273.png" /> SIGORDANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_274.png" /> SIGUGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_275.png" /> SIHALO HALO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_276.png" /> SIHAMBENG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_277.png" /> SIHAPAS HAPAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_278.png" /> SIHODA-HODA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_279.png" /> SIHOPUK BARU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_280.png" /> SIHOPUK LAMA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_281.png" /> SIJANTUNG JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_282.png" /> SIJANTUNG JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_283.png" /> SIJARA JARA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_284.png" /> SIJORANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_285.png" /> SILANGGE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_286.png" /> SILANTOYUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_287.png" /> SILOGO LOGO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_288.png" /> SILOUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_289.png" /> SIMADIHON<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_290.png" /> SIMAMBAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_291.png" /> SIMANAPANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_292.png" /> SIMANDIANGIN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_293.png" /> SIMANDIANGIN DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_294.png" /> SIMANDIANGIN LOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_295.png" /> SIMANGAMBAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_296.png" /> SIMANGAMBAT DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_297.png" /> SIMANGAMBAT JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_298.png" /> SIMANGAMBAT JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_299.png" /> SIMANGAMBAT TUA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_300.png" /> SIMANINGGIR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_301.png" /> SIMANINGGIR SIMUNDOL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_302.png" /> SIMANINGGIR SIP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_303.png" /> SIMANOSOR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_304.png" /> SIMARDONA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_305.png" /> SIMASI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_306.png" /> SIMATANIARI<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_307.png" /> SIMATANIARI JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_308.png" /> SIMATORKIS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_309.png" /> SIMBOLON<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_310.png" /> SIMUNDOL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_311.png" /> SINABONGAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_312.png" /> SINGANYAL<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_313.png" /> SIOMBOB<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_314.png" /> SIONGGOTON<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_315.png" /> SIPAHO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_316.png" /> SIPENGGENG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_317.png" /> SIPIONGOT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_318.png" /> SIPIROK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_319.png" /> SIPOGAS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_320.png" /> SIPOGAS A<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_321.png" /> SIPUPUS LOMBANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_322.png" /> SIRAGA HP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_323.png" /> SIRANAP<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_324.png" /> SIRINGKI JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_325.png" /> SIRINGKI JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_326.png" /> SITABAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_327.png" /> SITABOLA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_328.png" /> SITANGGORU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_329.png" /> SITONUN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_330.png" /> SITOPAYAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_331.png" /> SITUMBAGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_332.png" /> SIUNGGAM DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_333.png" /> SIUNGGAM JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_334.png" /> SIUNGGAM JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_335.png" /> SIUNGGAM TONGA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_336.png" /> SOBAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_337.png" /> SOSOPAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_338.png" /> SUKA DAME<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_339.png" /> SUNGAI BATAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_340.png" /> SUNGAI DURIAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_341.png" /> SUNGAI OROSAN<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_342.png" /> SUNGAI PINING<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_343.png" /> SUNGAI TOLANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_344.png" /> SUNUT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_345.png" /> TAMOSU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_346.png" /> TANGGA-TANGGA HAMBENG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_347.png" /> TANJUNG BARU B<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_348.png" /> TANJUNG BOTUNG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_349.png" /> TANJUNG LONGAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_350.png" /> TANJUNG MARIA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_351.png" /> TANJUNG MARULAK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_352.png" /> TANJUNG SALAMAT<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_353.png" /> TANJUNG TIRAM<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_354.png" /> TAPUS JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_355.png" /> TARUTUNG BOLAK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_356.png" /> TJ. BARU SILAIYA<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_357.png" /> TOBING TINGGI UB<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_358.png" /> TORLUK MUARA DOLOK<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_359.png" /> UBAR<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_360.png" /> UJUNG BATU JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_361.png" /> UJUNG BATU JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_362.png" /> UJUNG GADING JAE<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_363.png" /> UJUNG GADING JULU<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_364.png" /> UJUNG PADANG<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_365.png" /> ULAK TANO<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_366.png" /> UNTE MANIS<br />\
    <img src="styles/legend/Desa_Paluta_TitikKoordinat_1_367.png" /> <br />' });
var format_TitikCentroidDesa_2 = new ol.format.GeoJSON();
var features_TitikCentroidDesa_2 = format_TitikCentroidDesa_2.readFeatures(json_TitikCentroidDesa_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_TitikCentroidDesa_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_TitikCentroidDesa_2.addFeatures(features_TitikCentroidDesa_2);
cluster_TitikCentroidDesa_2 = new ol.source.Cluster({
  distance: 30,
  source: jsonSource_TitikCentroidDesa_2
});
var lyr_TitikCentroidDesa_2 = new ol.layer.Vector({
                declutter: false,
                source:cluster_TitikCentroidDesa_2, 
                style: style_TitikCentroidDesa_2,
                popuplayertitle: 'Titik CentroidDesa',
                interactive: true,
                title: '<img src="styles/legend/TitikCentroidDesa_2.png" /> Titik CentroidDesa'
            });
var format_DataKoordinatbetul_3 = new ol.format.GeoJSON();
var features_DataKoordinatbetul_3 = format_DataKoordinatbetul_3.readFeatures(json_DataKoordinatbetul_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_DataKoordinatbetul_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_DataKoordinatbetul_3.addFeatures(features_DataKoordinatbetul_3);
cluster_DataKoordinatbetul_3 = new ol.source.Cluster({
  distance: 30,
  source: jsonSource_DataKoordinatbetul_3
});
var lyr_DataKoordinatbetul_3 = new ol.layer.Vector({
                declutter: false,
                source:cluster_DataKoordinatbetul_3, 
                style: style_DataKoordinatbetul_3,
                popuplayertitle: 'Data Koordinatbetul',
                interactive: true,
                title: '<img src="styles/legend/DataKoordinatbetul_3.png" /> Data Koordinatbetul'
            });

lyr_OSMStandard_0.setVisible(true);lyr_Desa_Paluta_TitikKoordinat_1.setVisible(true);lyr_TitikCentroidDesa_2.setVisible(true);lyr_DataKoordinatbetul_3.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_Desa_Paluta_TitikKoordinat_1,lyr_TitikCentroidDesa_2,lyr_DataKoordinatbetul_3];
lyr_Desa_Paluta_TitikKoordinat_1.set('fieldAliases', {'OBJECT_ID': 'OBJECT_ID', 'KODE_DESA': 'KODE_DESA', 'DESA': 'DESA', 'PROVINSI': 'PROVINSI', 'KAB_KOTA': 'KAB_KOTA', 'KECAMATAN': 'KECAMATAN', 'JUMLAH_PEN': 'JUMLAH_PEN', 'JUMLAH_KK': 'JUMLAH_KK', 'LUAS_WILAY': 'LUAS_WILAY', 'KEPADATAN': 'KEPADATAN', 'WAJIB_KTP': 'WAJIB_KTP', 'PRIA': 'PRIA', 'WANITA': 'WANITA', 'PERSENTASE': 'PERSENTASE', 'TAHUN': 'TAHUN', 'Atribut_Pa': 'Atribut_Pa', });
lyr_TitikCentroidDesa_2.set('fieldAliases', {'ID': 'ID', 'Nama_Kelur': 'Nama_Kelur', 'S': 'S', 'E': 'E', 'Photo': 'Photo', });
lyr_DataKoordinatbetul_3.set('fieldAliases', {'ID': 'ID', 'Nama_Kelurahan': 'Nama_Kelurahan', 'S': 'S', 'E': 'E', });
lyr_Desa_Paluta_TitikKoordinat_1.set('fieldImages', {'OBJECT_ID': 'TextEdit', 'KODE_DESA': 'TextEdit', 'DESA': 'TextEdit', 'PROVINSI': 'TextEdit', 'KAB_KOTA': 'TextEdit', 'KECAMATAN': 'TextEdit', 'JUMLAH_PEN': 'TextEdit', 'JUMLAH_KK': 'TextEdit', 'LUAS_WILAY': 'TextEdit', 'KEPADATAN': 'TextEdit', 'WAJIB_KTP': 'TextEdit', 'PRIA': 'TextEdit', 'WANITA': 'TextEdit', 'PERSENTASE': 'TextEdit', 'TAHUN': 'TextEdit', 'Atribut_Pa': 'TextEdit', });
lyr_TitikCentroidDesa_2.set('fieldImages', {'ID': 'TextEdit', 'Nama_Kelur': 'TextEdit', 'S': 'TextEdit', 'E': 'TextEdit', 'Photo': 'ExternalResource', });
lyr_DataKoordinatbetul_3.set('fieldImages', {'ID': 'Range', 'Nama_Kelurahan': 'TextEdit', 'S': 'TextEdit', 'E': 'TextEdit', });
lyr_Desa_Paluta_TitikKoordinat_1.set('fieldLabels', {'OBJECT_ID': 'inline label - always visible', 'KODE_DESA': 'inline label - always visible', 'DESA': 'inline label - always visible', 'PROVINSI': 'inline label - always visible', 'KAB_KOTA': 'inline label - always visible', 'KECAMATAN': 'inline label - always visible', 'JUMLAH_PEN': 'inline label - always visible', 'JUMLAH_KK': 'inline label - always visible', 'LUAS_WILAY': 'inline label - always visible', 'KEPADATAN': 'inline label - always visible', 'WAJIB_KTP': 'inline label - always visible', 'PRIA': 'inline label - always visible', 'WANITA': 'inline label - always visible', 'PERSENTASE': 'inline label - always visible', 'TAHUN': 'inline label - always visible', 'Atribut_Pa': 'no label', });
lyr_TitikCentroidDesa_2.set('fieldLabels', {'ID': 'inline label - always visible', 'Nama_Kelur': 'inline label - always visible', 'S': 'inline label - always visible', 'E': 'inline label - always visible', 'Photo': 'inline label - always visible', });
lyr_DataKoordinatbetul_3.set('fieldLabels', {'ID': 'inline label - always visible', 'Nama_Kelurahan': 'inline label - always visible', 'S': 'inline label - always visible', 'E': 'inline label - always visible', });
lyr_DataKoordinatbetul_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});